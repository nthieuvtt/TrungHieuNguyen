-- standardlize Date 
select SaleDate, convert(Date, SaleDate) from dbo.housing 

Alter table dbo.housing 
add SaleDateConvert Date

update dbo.housing
set SaleDateConvert = convert(Date, SaleDate)select * from dbo.housing


---------------------------------------------------
-- Populate  property address data
select * from dbo.housing
--where PropertyAddress is null 
order by ParcelID

select a.ParcelID , a.PropertyAddress ,b.ParcelID , b.PropertyAddress, isnull(a.PropertyAddress, b.PropertyAddress), a.[UniqueID ], b.[UniqueID ]
from dbo.housing a
join dbo.housing b 
on a.ParcelID = b.ParcelID 
and a.[UniqueID ] <> b.[UniqueID ]
where a.PropertyAddress is null

update a 
set PropertyAddress =isnull(a.PropertyAddress, b.PropertyAddress)
from dbo.housing a
join dbo.housing b 
on a.ParcelID = b.ParcelID 
and a.[UniqueID ] <> b.[UniqueID ]
where a.PropertyAddress is null

--------------------------------------
--Breaking out Address into Individual Columns(Address, City, State)

select OwnerAddress
from dbo.housing

select 
PARSENAME(REPLACE (OwnerAddress, ',' , '.'),3),
PARSENAME(REPLACE (OwnerAddress, ',' , '.'),2),
PARSENAME(REPLACE (OwnerAddress, ',' , '.'),1)
from dbo.housing

alter table dbo.housing
add OwnerSplitAddress Nvarchar(255)

alter table dbo.housing
add OwnerSplitCity Nvarchar(255)

alter table dbo.housing
add OwnerSplitState Nvarchar(255)

update housing
set OwnerSplitAddress = PARSENAME(REPLACE (OwnerAddress, ',' , '.'),3)

update housing
set OwnerSplitCity = PARSENAME(REPLACE (OwnerAddress, ',' , '.'),2)

update housing
set OwnerSplitState = PARSENAME(REPLACE (OwnerAddress, ',' , '.'),1)

select * from dbo.housing

-------------------------------------------------------------
--Change 'Y' and 'N' to Yes and No in " SolidaAsVacant"

select distinct(SoldAsVacant), count(SoldAsVacant) as total
from dbo.housing
group by SoldAsVacant
order by total desc

select SoldAsVacant
, case when SoldAsVacant = 'Y' then 'Yes'
when SoldAsVacant = 'N' then 'No'
else SoldAsVacant
END
from dbo.housing

update dbo.housing 
set SoldAsVacant = case when SoldAsVacant = 'Y' then 'Yes'
when SoldAsVacant = 'N' then 'No'
else SoldAsVacant
END

-------------------------------

-- Remove Duplicates

WITH RowNumCTE AS (
select *, 
ROW_NUMBER() OVER (
	Partition by ParcelID,PropertyAddress,SaleDate,SalePrice,LegalReference
	order by UniqueID ) row_num
from dbo.housing
--order by  ParcelID
)
select *
from RowNumCTE
where row_num > 1
order by PropertyAddress

----------------------------------------------------------------------------
--Delete Unused Columns
alter table dbo.housing
drop column SaleDateConvert

select * from dbo.housing